<script src="<?= base_url('assets/landing/js/vendor/jquery-2.2.4.min.js'); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="<?= base_url('assets/landing/js/vendor/bootstrap.min.js'); ?>"></script>
<!-- <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script> -->
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="<?= base_url('assets/landing/js/easing.min.js'); ?>"></script>
<script src="<?= base_url('assets/landing/js/hoverIntent.js'); ?>"></script>
<script src="<?= base_url('assets/landing/js/superfish.min.js'); ?>"></script>
<script src="<?= base_url('assets/landing/js/jquery.ajaxchimp.min.js'); ?>"></script>
<script src="<?= base_url('assets/landing/js/jquery.magnific-popup.min.js'); ?>"></script>
<script src="<?= base_url('assets/landing/js/owl.carousel.min.js'); ?>"></script>
<script src="<?= base_url('assets/landing/js/jquery.sticky.js'); ?>"></script>
<script src="<?= base_url('assets/landing/js/jquery.nice-select.min.js'); ?>"></script>
<script src="<?= base_url('assets/landing/js/waypoints.min.js'); ?>"></script>
<script src="<?= base_url('assets/landing/js/jquery.counterup.min.js'); ?>"></script>
<script src="<?= base_url('assets/landing/js/parallax.min.js'); ?>"></script>
<script src="<?= base_url('assets/landing/js/mail-script.js'); ?>"></script>
<script src="<?= base_url('assets/landing/js/main.js'); ?>"></script>
<script src="<?= base_url('assets/dashboard/js/rental.js'); ?>"></script>